#  Write a Python program to calculate the area of a parallelogram 

# take a variable b and h  
b=int(input("enter the No :"))
h=int(input("enter the No :"))
# perform action in j
j=b*h
# print the result 
print(j)