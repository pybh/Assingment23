# Write a Python program to find the length of a tuple.
# make a tuple name tuple1
tuple1=("python", "india")
# print the result 
print(len(tuple1))
