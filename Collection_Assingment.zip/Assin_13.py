# Write a Python program to select an item randomly from a list.

# import random module
import random
# take a list name listt 

listt=["python","java","php","C"]
# print the result 
print(random.choice(listt))