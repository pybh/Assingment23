#  Write a Python program to calculate surface volume and area of a 
# cylinder

# import math module 
import math
# take variable name r and h and j
r=float(input("enter the value : "))
h=float(input("enter the value : "))
j=3.14*(r*r)*h
# print the result
print("volume of cylinder : ",j)
h=2*3.14*r*(h+r)
# print the result 
print("area of cylinder : ",h)