#  Write a Python program to convert a list of characters into a string. 

# take a list name listt 
listt=["p","y","t","h","o","n"]
# now take a variable x 
x=listt
# now take a  new variable y use join function
y="".join(x)
# print the result 
print(y)