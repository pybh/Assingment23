# How will you remove last object from a list? 
# Suppose list1 is [2, 33, 222, 14, and 25], what is list1 [-1]?

# Take a list of list1
list1 = [2, 33, 222, 14,  25]
# now use list inbuilt function
list1.pop()
# print the list1
print(list1)