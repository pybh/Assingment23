# What is List? How will you reverse a list?

# take a list of name listt
listt=["python","java","php","larvel"]
# now run listt inbuit function
listt.reverse()
# print The List
print(listt)


# list is a collection of elements and reverse list is print reverse element