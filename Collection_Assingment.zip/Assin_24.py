#    Write a Python program to convert a list to a tuple. 

# take a list name listt
listt=["Apple","India","python","java"]
# now take a variable x  
x=tuple(listt)
# print the result 
print(x)
