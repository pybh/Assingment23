# Write a Python program to split a list into different variables. 
# now take a variable strr
strr="welcome to india"
# make a different variable x and perform split function
x=strr.split()
# make a tmp variable for store the result 
tmp=x
# print the result 
print(tmp)
