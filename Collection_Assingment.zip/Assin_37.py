#  Write a Python script to print a dictionary where the keys are numbers between 1 and 15. 

# take a dictionary name  dictt
dictt={}
# now initiate a for loop
for i in range(1,16):
    # make a dictionary key value pair
    dictt[i]=i
    # print the result 
print(dictt)