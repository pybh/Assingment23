# How can you pick a random item from a list or tuple? 

# import random module
import random
# take a list name listt
listt=[1,2,34,8,5,7,9,4]
# use random inbuilt function 
r=random.choice(listt)
# print result 
print(r)