# Write a Python program to combine values in python list of dictionaries. 
# Sample data: [{'item': 'item1', 'amount': 400}, {'item': 'item2', 'amount': 
# 300}, o {'item': 'item1', 'amount': 750}] 



# make a dictionary name dictt
dictt={'item': 'item1',
       'amount': 400
      }
# make a dictionary name dictt1
dictt1={
    'item': 'item2', 
    'amount': 300
    }
# make a dictionary name dictt2
dictt2={'item': 'item1',
        'amount': 750
       }
# now take a variable name x
x=dictt.get('item1',400)+ dictt2.get('item1',750)
# print the result
print("item1 :",x,end=" ")
print("item2 :",300)