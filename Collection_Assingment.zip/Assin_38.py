#  Write a Python program to check multiple keys exists in a dictionary

# make a dictionary name dictt
dictt={
    "harsh" : 1,
    "hi" : 2,
    "jing" : 3 
}
# take user input from th user
keys1 =input("enter 1st : ")
keys2 =input("enter 2nd : ")
# make a if condition
if keys1 and keys2 in dictt or keys1 in dictt or keys2 in dictt:
    # print the values
    print("keys are there or one key is there")
# make a else condition
else:
    # print the values
    print("keys are not there")