#  Write a Python program to count the number of strings where the string 
# length is 2 or more and the first and last character are same from a given 
# list of strings
 
# now make a function of name my
def my(listt1):
     # initilize a count from zero
     count=0
     # initiate a for loop 
     for i in listt1:
          #   now make a condition of len is equal and compare it
            if(len(i) >=2 and i[0]==i[-1]):
               #  when condition match we increment the count
                count+=1
               #  return the count 
     return count

# make a list name listt1
listt1=["python","larvel","CC"]
# now call the function  
x=my(listt1)
# print the value
print(x)