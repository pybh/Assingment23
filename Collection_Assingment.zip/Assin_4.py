#  Write a Python function to get the largest number, smallest num and sum 
# of all from a list

# Take a list name List1 
list1=[12,56,23,44,1]
# print and use list max function
print(max(list1))
# print and use list min function
print(min(list1))
# now  sum of all elements in list 
x=sum(list1)
# print the sum of all list
print(x)