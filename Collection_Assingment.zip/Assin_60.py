#  Write a Python program to calculate the area of a trapezoid 

# take three variable name num1,num2,num3
num1=int(input("enter a area of base1 :"))
num2=int(input("enter a area of base2 :"))
num3=int(input("enter a area of height :"))
Area = 0.5 * (num1 + num2) * num3
# print the result 
print("Area of trapezoid :",Area)