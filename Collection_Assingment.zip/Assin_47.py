#  Write a Python program to create a dictionary from a string. 
# Note: Track the count of the letters from the string. 
# Sample string: 'w3resource'

# take a string anme strr 
strr= 'w3resource'
# take a empty dictionary name dictt
dictt={}
# now initiate the for loop
for i in strr:
    # fetching values from get
    dictt[i]=dictt.get(i,0)+1
# print the result 
print(dictt)