#  How will you compare two lists?

# take a list1
list1 = ["harsh","Legend","himo"]
# take a list2
list2 = ["harsh","Legend",]

# initiate a for loop 
for j in list1:
    pass
    # make a  if Condition 
if j in list2:
    # print the value
    print(True )
    # make a else condition 
else:
    # print a value
    print(False)

    