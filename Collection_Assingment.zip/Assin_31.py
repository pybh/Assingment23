#  How will you create a dictionary using tuples in python? 

# make a list name listt
listt=[("py","th",),("ja","va")]
# make a different varaible j
j=dict(listt)
# print the type of result 
print(type(j))
# print the result
print(j)