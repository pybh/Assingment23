
# Differentiate between append () and extend () methods? 

# take a list name listt
listt=["python","java","php","larvel"]
# now run the list inbuilt funstion name append 
listt.append(".net")
# print the List 
print(listt)

# take a list name listt1
listt1=["python","java","php","larvel"]
# take a list name listt2
listt2=["C","Android","Computer","Web"]
# now run the list inbuilt funstion name extend
listt1.extend(listt2)
# print the list
print(listt1)
