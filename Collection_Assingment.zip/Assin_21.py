#  Write a Python program to convert a tuple to a string.

#  Make a tuple name of my_tuple
my_tuple=("python","is","a","language")
# now make a variable e perform the logic
e=(str(" ".join(my_tuple)))
# print the result 
print(e)