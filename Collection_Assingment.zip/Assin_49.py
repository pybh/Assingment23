# Write a Python function to check whether a number is in a given range

# make a function newranges
def newranges(n):
    # make a if condition 
    if n in range(2,100):
        # return the value
        return("is in range")
    # make a else condition
    else:
        # return the value
        return("not in Range")
    # take a user input
n=int(input("enter the no : " ))
# print the result 
print(newranges(n))