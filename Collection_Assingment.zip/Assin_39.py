#  Write a Python script to merge two Python dictionaries

# now take a dictionary name dictt
dictt={
    "harsh":1,
    "sj":2
}
# now take a dictionary name dictt1
dictt1={
    "jsb":4,
    "dd":8
}
# Now add two dictionary using update method 
z=dictt.update(dictt1)
# print the result 
print(dictt)