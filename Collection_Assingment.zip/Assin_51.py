# Write a Python function that checks whether a passed string is 
# palindrome or not 

# create a function name palindrome
def palindrome(n):
    # make a if condition
    if n==n[::-1]:
        # return a value
        return "the string is palindrome"
    # make a else condition
    else:
        # return the value
        return "the string is not palindrome"
        
        # take a user input 
n=input("enter the string : ")
# print the result 
print(palindrome(n))