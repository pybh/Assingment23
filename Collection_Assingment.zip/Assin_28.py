#  Write a Python program to remove an empty tuple(s) from a list of tuples. 

# make a tuple name tuple1
tuple1=[(), ("india"),(),("python","java"),()]
# initiate a for loop
for i in tuple1:
    # use a inbuilt function remove
    tuple1.remove(i)
# print the result 
print(tuple1)