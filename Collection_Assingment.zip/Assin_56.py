#  How will you set the starting value in generating random numbers?

 # import random module
import random
# use random function seed 
random.seed(5)
# print the result
print(random.random())