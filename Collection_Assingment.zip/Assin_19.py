#  Write a Python program to create a tuple with different data types

# Now a tuple name int_tuple 
int_tuple=(11,12,3,4,5,6)
# print the result
print("numeric :",int_tuple)

# Now a tuple name float_tuple 
float_tuple=(12.3,3.4,1.2,5.6)
# print the result
print("float :",float_tuple)

# Now a tuple name string_tuple 
string_tuple=("orange","apple","cherry","chiku")
# print the result
print("string :",string_tuple)

# Now a tuple name boolean_tuple 
boolean_tuple=(True,False)
# print the result
print("boolean :",boolean_tuple)