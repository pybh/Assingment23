#  Write a Python script to check if a given key already exists in a dictionary

# make a dictionary name dictt
dictt = {
    "Python": "data Science",
    "java": "dsa",
    "html": "website",
    "javascript":"web devlopment"
    
}
# now take a user input 
h=input("enter the key : ")
# make a if condition 
if h in dictt:
    # print the value
    print("yes")
# make a else condition 
else:
    # print the value
    print("no")