# Write a Python function that takes two lists and returns true if they have 
# at least one common member. 

# take a list1
list1 = [1, 3, 4, 55]
# take a list2
list2 = [90, 22,]
# initiate a count
count = 0
# initilize a loop 
for j in list2:
    # now make a condition 
    if j in list1:
        # increment the count
        count = 1
        # make a  new if condition
if count == 1:
    # print the value
    print("True")
    # make a else condition 
else :
#  print a value
    print("False")