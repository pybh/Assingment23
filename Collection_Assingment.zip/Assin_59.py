#  Write a Python program to convert degree to radian

# import math module 
import math
# print the result 
print(math.radians(120))
