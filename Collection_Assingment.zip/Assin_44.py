#  Write a Python program to create and display all combinations of letters, 
# selecting each letter from a different key in a dictionary. 

# make a dictionary name dictt
dict1={
    '1': ['a','b'], 
    '2': ['c','d']
 }
# now perform some operator on different variable
n1="a"+"c"
n2="a"+"d"
n3="b"+"c"
n4="b"+"d"
# print the desired result 
print(n1,end=" ")
print(n2,end=" ")
print(n3,end=" ")
print(n4,end=" ")