# Write a Python function that takes a list and returns a new list with unique 
# elements of the first list. 

# make a list
listt=["python","java","C","python","php",1,3,4,4,5,6,7,7]
# now typecaste a list into set
x=set(listt)
# now typecaste a set into list
listt=list(x)
# print the result 
print(listt)
