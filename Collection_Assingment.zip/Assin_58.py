#  Write a Python program to read a random line from a file

# # import random module
import random
# make a function name random_line 
def random_line(fname):
    lines = open(fname).read().splitlines()
    # return the function
    return random.choice(lines)
# print the result 
print(random_line("test.txt"))