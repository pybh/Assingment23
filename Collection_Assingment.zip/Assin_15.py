#  Write a Python program to get unique values from a list 
# take a list name listt
listt=[1,2,1,5,5,3,3,4,4,6,7,6,7,8]
# take a empty list Name listt1
listt1=[]
# now initiate for loop 
for j in listt:
    # now apply a if condition
    if j  not in listt1:
        # now append the list
        listt1.append(j)

# print the result
print(listt1)

        

    
