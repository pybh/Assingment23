#  Write a Python function to check whether a number is perfect or not.

# create a h function
def h(n):
    # take a variable name sum =0
    sum=0
    # now initiate a for loop
    for x in range(1,n):
        # make a if condition
        if n%x==0:
            # now a certain condition increment sum
            sum+=x
            # return the sum
    return sum==n
# print the result
print(h(28))       