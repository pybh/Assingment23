# Write a Python program to find the repeated items of a tuple. 

# make a tuple name tuple1
tuple1=(1,2,2,3,3,5,9,6,2,2,54,9)
# take a count variable 
count=tuple1.count(2)
# print the result
print(count)
