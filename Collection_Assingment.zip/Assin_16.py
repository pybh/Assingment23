#  Write a Python program to check whether a list contains a sub list

# take a list name listt
listt=["python","java","php","C"]
# take a new list name sub_list 
sub_list=["java"]
# now take a new variablr x
x=[listt,sub_list]
# print the result z
print(x)   