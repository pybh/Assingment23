# Write a Python program to find the highest 3 values in a dictionary

# make a dictionary name dictt
dictt={
    "harsh":44,
    "havg":85,
    "ajdh":105,
    "hajbsb":76
}
# make a variable name s and j
s=dictt.values()
j=list(s)
# sort the element 
j.sort()
# print the result 
print(j[1::])