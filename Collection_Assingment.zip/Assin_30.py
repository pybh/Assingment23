#  Write a Python program to convert a list of tuples into a dictionary

# make a tuple name tuple1
tuple1=[("Nakul", 93), ("Shivansh", 45), ("Samved", 65),
          ("Yash", 88), ("Vidit", 70), ("Pradeep", 52)]
# make a new variable
x=dict(tuple1)
# print the result 
print(x)
