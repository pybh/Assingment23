# Write a Python program to unzip a list of tuples into individual lists

# make a list name listt
listt=[(1,"harsh"),(2,"himo"),(3,"Legend")]
# take two empty list name l and j
l=[]
j=[]
# initiate the for loop
for k,m in listt:
    # append the list 
    l.append(k)
    j.append(m)
# print the result
print(l)
print(j)