#  How can you get a random number in python? 

# # import random module
import random
# print the result
print(random.random())