# Write a Python script to sort (ascending and descending) a dictionary by value. 

# take a dictionary name dictt
dictt={'Nakul': 93, 
      'Shivansh': 45, 
      'Samved': 65,
      'Yash': 88, 
      'Vidit': 70, 
      'Pradeep': 52}
# Ascending Order
x=list(dictt.values())
# using sort function
x.sort()
# typecaste to dictionary
dictt=x
# print the result
print(x)

# Descending Order
x.sort(reverse=True)
# typecaste to dictionary
dictt=x
# print the result 
print(x)