#  Write a Python program to generate and print a list of first and last 5 
# elements where the values are square of numbers between 1 and 30. 

# make function name h
def h():
    # take a variable j in list
    j=list()
    # now initiate a for loop 
    for k in range(1,21):
        # now use append to add the value
        j.append(k**2)
        # print the result
    print(j[:5])
    print(j[-5:])
    # call the function
h()