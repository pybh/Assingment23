#  How can you pick a random item from a range? 

# # import random module
import random
# use random module function
k=random.choice(range(1,20))
# print the result
print(k)