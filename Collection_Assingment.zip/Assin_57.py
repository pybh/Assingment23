# How will you randomizes the items of a list in place?

# # import random module
import random
# make list name listt
listt=[1,"ahrsh",44,64,6,"hasa"]
j=random.choice(listt)
# print the result
print(j)
k=random.choices(listt)
# print the result
print(k)