#  Write a Python program to map two lists into a dictionary

# make a list name of keys and values 
keys = ['name', 'age', 'job']
values = ['John', 25, 'Developer']
# now convert the list into dictinary using zip method 
dictt=dict(zip(keys,values))
# print the result
print(dictt)    