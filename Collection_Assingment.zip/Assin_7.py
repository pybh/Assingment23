#  Write a Python program to remove duplicates from a list.

# take a list name listt1
 
listt1=[2,1,2,3,1,33,4]
# now type caste to a set 
 
x=(list(set(listt1)))
# print the value
print(x)

# remove duplicate values

lst = [67 , 78 ,67 ,90] 
g = set(lst)
lst = g 
print(lst)
