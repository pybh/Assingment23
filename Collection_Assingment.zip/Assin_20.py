#  Write a Python program to create a tuple with numbers. 

#  Take a tuple name my_tuple
my_tuple=(2,4,5,-1,0,-2)
# print the result 
print(my_tuple)
