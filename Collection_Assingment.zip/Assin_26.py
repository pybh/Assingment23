# Write a Python program to replace last value of tuples in a list.

# make a tuple of name tuple1
tuple1=("python", "india","java","apple")
# now make a variable name x 
x=str(tuple1)
# use replace inbuitl function
tuple1=x.replace("apple","orange")
# print the result 
print(tuple1)