#  Write a Python program to print all unique values in a dictionary. 

# make a dictionary name dictt
dictt={
    "harsh":1,
    "aibs":2,
    "ha" :1,
    "ja":2,
    "ka":3
}
# now take a variable name z
z=dictt.values()
# now take a empty list j
j=[]
# now initiate the for loop 
for i in z:
# make a if condition
    if i not in j:
        # append to empty list
        j.append(i)
        # print the result
print(j)