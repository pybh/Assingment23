#  Write a Python program to check whether an element exists within a tuple


#  make a tuple name of my_tuple
my_tuple=("python","is","a","language")
# take a variable name x having string value 
x="python"
# now initiate for loop
for i in my_tuple:
    #    make a  if condition 
       if(x==i):
            #   print the result 
              print("Yes this element is in tuple")
            #   use break for a stopping value 
              break
        
