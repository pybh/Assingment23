#  Write a Python program to find the second smallest number in a list.

# take a list name list
list=[1,5,8,7,46,45]
# take a variable name h and j
h=list[0]
j=list[1]
# now initiate the loop
for i in range(2,len(list)):
    # now make a if condition
    if list[i] < h:
        j=h
        h=list[i]
    # make a elif condition     # 
    elif list[i] < h:
        j=list[i]
    # print the result
print(j)
print(h)
