# Write a Python program to returns sum of all divisors of a number 

# create a function fun
def fun(n):
    # the list f having 1
    f = [1]
    # now initiate for loop
    for i in range(2,n):
        # make a if condition
        if n % i==0:
            # append in lsit f
            f.append(i)
            # return the value
    return sum(f)
# print the result 
print(fun(5))
print(fun(10))            
