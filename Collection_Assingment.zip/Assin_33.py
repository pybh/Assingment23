#  Write a Python script to concatenate following dictionaries to create a new one.

# take a dictionary name dictt
dictt={
    "Name":"Bhagya",
    "lname":"Patel",
    "Desgination":"python Devloper"
    
}

# take a dictionary name dictt1
dictt1={
    "Fruits" : "Apple",
    "Color" : "Red",
    "Quantity" : 2

}
# take a dictionary name dictt3
dictt3={
    "dictt" :dictt,
    "dictt1":dictt1
}
# print the result
print(dictt3)