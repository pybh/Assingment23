#  Write a Python program to check a list is empty or not. 

# now take a list name Listt
listt=["python","java","php","larvel"]
# make a if condition
if(listt.clear()):
    # print the value
    print(listt)
    # make a else condition
else:
    # print the value
    print(listt)