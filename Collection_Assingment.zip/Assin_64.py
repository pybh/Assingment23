#  Write a Python program to find the maximum and minimum numbers 
# from the specified decimal numbers. 

# take two variable x and y
x=min(2.4,2.5,4.5,5.5)
y=max(2.3,2.5,3.5,5.5)
# print the result 
print(x)
print(y)

