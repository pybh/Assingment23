#  Write a Python program to reverse a tuple. 

#  make a tuple name tuple1
tuple1=("python", "india","java","apple")
# now take a variable name x
x=list(tuple1)
# now perform reverse operation
x.reverse()
# now convert list to tuple 
tuple1=tuple(x)
# print the result 
print(tuple1)