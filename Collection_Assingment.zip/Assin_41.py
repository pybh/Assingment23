#  Write a Python program to combine two dictionary adding values for common keys.

# make a dictionary name dictt
dictt = {'a': 100, 
      'b': 200, 
      'c':300
      } 
# make a dictionary name dictt1
dictt1 = {'a': 300, 
      'b': 200,
      'd':400
      } 
# make a variable name x and y
x=dictt.get('a',100)+ dictt1.get('a',300)
y=dictt.get('b',200)+ dictt1.get('b',200)
# print the result 
print("a :",x,end=" ")
print("b :",y,end=" ")
print("c :",300)