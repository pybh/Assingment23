# How Do You Traverse Through A Dictionary Object In Python? 

# start a infinite loop
while True:
    # now take a user input
    num=int(input("Enter a number between 1 to 15:"))
    # make a if condition
    if(num > 1) and (num < 15):
        # dictionary in which we have to traverse
        dictt={
                "Name":"Bhagya",
                "lname":"Patel",
                "Desgination":"python Devloper"
    
             }
        # print the result 
        print(dictt)
        # break the loop
    break
    