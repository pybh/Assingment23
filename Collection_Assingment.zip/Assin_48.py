# Write a Python function to calculate the factorial of a number (a nonnegative integer)

# create  a function factorial  
def factorial(n):
    # make a if condition 
    if n == 0:
    #   return the value
      return 1
    # make a else condition
    else:
    #    return the value
       return n * factorial(n - 1)

# take  a user input 
n = int(input("Input a number to compute the factorial: "))
# print the result
print(factorial(n))
